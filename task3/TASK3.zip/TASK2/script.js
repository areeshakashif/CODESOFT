// javascript for calculator
let currentOutput = "";

function clearOutput() {
    currentOutput = currentOutput.slice(0, -1);
    document.getElementById("output").textContent = currentOutput || "0";
}
// functions for calculator

function clearAll() {
    currentOutput = "";
    document.getElementById("output").textContent = "0";
}
function appendToOutput(value) {
    if (value === 'sqrt') {
        currentOutput += Math.sqrt(parseFloat(currentOutput));
    } else {
        currentOutput += value;
    }
    document.getElementById("output").textContent = currentOutput;
}

function calculateResult() {
    try {
        currentOutput = eval(currentOutput);
        document.getElementById("output").textContent = currentOutput;
    } catch (error) {
        document.getElementById("output").textContent = "Error";
    }
}
